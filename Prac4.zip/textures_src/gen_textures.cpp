/*
    Golf Ball Texture Generator
    Creates three PGM/PPM texture maps procedurally:
    1. colour_map.ppm   - dimple shading (darker circles on lighter background)
    2. displacement_map.pgm - height map for dimples (greyscale)
    3. alpha_map.pgm    - alpha mask (dimples = transparent, rest = opaque)

    Algorithm:
    tile a hexagonal grid of circles across UV space to approximate dimples.
    Each texel is tested against the nearest circle centre; if within radius it is considered a "dimple", otherwise "surface".
 */

#include <cstdio>
#include <cmath>
#include <cstring>
#include <iostream>

static const int TEX_W = 512;
static const int TEX_H = 512;

//Hexagonal grid parameters to control dimple density
//cols x rows determines number of dimples
static const int COLS = 22;
static const int ROWS = 22;
static const float DIMPLE_RADIUS = 0.38f; //fraction of cell size for dimple space is 38% of cell size

struct RGB { unsigned char r, g, b; };

//Returns true if (u,v) in [0,1]x[0,1] inside a dimple
//Also returns distance from nearest dimple centre (0=centre, 1=edge)
bool inDimple(float u, float v, float &dist) {
    float cellW = 1.0f / COLS;
    float cellH = 1.0f / ROWS;
    float radius = DIMPLE_RADIUS * fmin(cellW, cellH);

    float minDist = 1e9f;

    //Check 3x3 cluster of cells
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            //Compute which cell (u,v) would map to
            int ci = (int)(u / cellW) + dx;
            int cj = (int)(v / cellH) + dy;

            //Hex offset is every other row shifts by half a cell width
            float ox = (cj % 2 == 0) ? 0.0f : cellW * 0.5f;

            float cx = (ci + 0.5f) * cellW + ox; //dimple centre X and Y
            float cy = (cj + 0.5f) * cellH;

            float du = u - cx;
            float dv = v - cy;
            float d = sqrtf(du*du + dv*dv);
            if (d < minDist) minDist = d;
        }
    }

    dist = minDist / radius;
    return dist < 1.0f;
}

void writePPM(const char* filename, RGB* pixels) { 
    FILE* f = fopen(filename, "wb");
    if (!f) { fprintf(stderr, "Cannot open %s\n", filename); return; }
    fprintf(f, "P6\n%d %d\n255\n", TEX_W, TEX_H);
    fwrite(pixels, sizeof(RGB), TEX_W * TEX_H, f);
    fclose(f);
    printf("Written: %s\n", filename);
}

void writePGM(const char* filename, unsigned char* pixels) {
    FILE* f = fopen(filename, "wb");
    if (!f) { fprintf(stderr, "Cannot open %s\n", filename); return; }
    fprintf(f, "P5\n%d %d\n255\n", TEX_W, TEX_H);
    fwrite(pixels, 1, TEX_W * TEX_H, f);
    fclose(f);
    printf("Written: %s\n", filename);
}

int main() {
    RGB*           colour_map      = new RGB[TEX_W * TEX_H];
    unsigned char* displacement_map = new unsigned char[TEX_W * TEX_H];
    unsigned char* alpha_map        = new unsigned char[TEX_W * TEX_H];

    for (int row = 0; row < TEX_H; row++) {
        for (int col = 0; col < TEX_W; col++) {
            float u = (col + 0.5f) / TEX_W;
            float v = (row + 0.5f) / TEX_H;

            float dist;
            bool dimple = inDimple(u, v, dist);

            int idx = row * TEX_W + col;

            //Surface = light grey-white golf ball colour
            //Dimple = darker grey shadow
            if (dimple) {
                //darker at centre, lighter at edge
                float t = dist; // 0 = centre, 1 = edge
                unsigned char shade = (unsigned char)(120 + (unsigned char)(60.0f * t));
                colour_map[idx] = {shade, shade, shade};
            } else {
                colour_map[idx] = {220, 220, 220}; //white surface
            }

            //Displacement
            if (dimple) {
                //Cosine falloff gives smoothest transition
                float depth = (1.0f + cosf(dist * 3.14159f)) * 0.5f; //1 at centre, 0 at edge
                unsigned char h = (unsigned char)(255.0f * (1.0f - 0.6f * depth));
                displacement_map[idx] = h;
            } else {
                displacement_map[idx] = 255; //flat surface = maximum height
            }

            //Alpha map
            if (dimple) {
                //Sharp edge with slight feather at border to avoid hard aliasing
                float feather = 0.1f;
                float t = 1.0f - dist; //1 at centre, 0 at edge
                float alpha;
                if (t < feather) //t = 1- dist, so t is small near edges
                    alpha = t / feather; //fade in last 10% of radius
                else
                    alpha = 1.0f;
                //Dimples are transparent, so invert
                alpha_map[idx] = (unsigned char)(255.0f * (1.0f - alpha));
            } else {
                alpha_map[idx] = 255; //opaque surface default
            }
        }
    }

    writePPM("colour_map.ppm", colour_map); //Writes binary colour image of RGB
    writePGM("displacement_map.pgm", displacement_map); //Writes binary greyscale image
    writePGM("alpha_map.pgm", alpha_map);

    delete[] colour_map;
    delete[] displacement_map;
    delete[] alpha_map;

    printf("All textures generated successfully.\n");
    return 0;
}
