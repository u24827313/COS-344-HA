#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <sstream>
#include <vector>

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#define STUDENT_NUMBER "u24597181"

// Matrix math
struct Mat4 {
    float m[16]; //column-major
    Mat4() { for(int i=0;i<16;i++) m[i]=(i%5==0)?1.0f:0.0f; } //identity matrix
};

Mat4 mat4Mul(const Mat4& a, const Mat4& b) { //4x4 Matrix Multiplication
    Mat4 r;
    for(int i=0;i<4;i++)
        for(int j=0;j<4;j++) {
            r.m[j*4+i] = 0;
            for(int k=0;k<4;k++)
                r.m[j*4+i] += a.m[k*4+i] * b.m[j*4+k];
        }
    return r;
}

Mat4 perspective(float fovY, float aspect, float near, float far) { //Build perspective projection matrix from FOV
    Mat4 r;
    for(int i=0;i<16;i++) r.m[i]=0;
    float tanHalf = tanf(fovY/2.0f);
    r.m[0]  = 1.0f/(aspect*tanHalf);
    r.m[5]  = 1.0f/tanHalf;
    r.m[10] = -(far+near)/(far-near);
    r.m[11] = -1.0f;
    r.m[14] = -(2.0f*far*near)/(far-near);
    return r;
}

Mat4 lookAt(glm::vec3 eye, glm::vec3 center, glm::vec3 up) { //View matrix from 3 axes (forward/right up)
    glm::vec3 f = glm::normalize(center - eye);
    glm::vec3 r = glm::normalize(glm::cross(f, glm::normalize(up)));
    glm::vec3 u = glm::cross(r, f);
    Mat4 m;
    m.m[0]=r.x; m.m[4]=r.y; m.m[8]=r.z;  m.m[12]=-glm::dot(r,eye);
    m.m[1]=u.x; m.m[5]=u.y; m.m[9]=u.z;  m.m[13]=-glm::dot(u,eye);
    m.m[2]=-f.x;m.m[6]=-f.y;m.m[10]=-f.z;m.m[14]=glm::dot(f,eye);
    m.m[3]=0;   m.m[7]=0;   m.m[11]=0;   m.m[15]=1;
    return m;
}

Mat4 rotateX(float angle) {
    Mat4 m;
    m.m[5] = cosf(angle); m.m[9]  = -sinf(angle);
    m.m[6] = sinf(angle); m.m[10] =  cosf(angle);
    return m;
}
Mat4 rotateY(float angle) {
    Mat4 m;
    m.m[0] = cosf(angle); m.m[8]  =  sinf(angle);
    m.m[2] =-sinf(angle); m.m[10] =  cosf(angle);
    return m;
}
Mat4 rotateZ(float angle) {
    Mat4 m;
    m.m[0] = cosf(angle); m.m[4] = -sinf(angle);
    m.m[1] = sinf(angle); m.m[5] =  cosf(angle);
    return m;
}
Mat4 translate(float x, float y, float z) {
    Mat4 m;
    m.m[12]=x; m.m[13]=y; m.m[14]=z;
    return m;
}
Mat4 scale(float s) {
    Mat4 m;
    m.m[0]=s; m.m[5]=s; m.m[10]=s;
    return m;
}

//Shader loading
GLuint loadShader(const char* vertPath, const char* fragPath) {
    auto readFile = [](const char* path) -> std::string {
        FILE* f = fopen(path, "r");
        if (!f) { fprintf(stderr, "Cannot open shader: %s\n", path); exit(1); }
        fseek(f, 0, SEEK_END); long sz = ftell(f); fseek(f, 0, SEEK_SET);
        std::string s(sz, '\0');
        fread(&s[0], 1, sz, f);
        fclose(f);
        return s;
    };

    std::string vs = readFile(vertPath);
    std::string fs = readFile(fragPath);
    const char* vsrc = vs.c_str();
    const char* fsrc = fs.c_str();

    GLuint vert = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vert, 1, &vsrc, NULL);
    glCompileShader(vert);
    GLint ok; glGetShaderiv(vert, GL_COMPILE_STATUS, &ok);
    if(!ok){char log[512]; glGetShaderInfoLog(vert,512,NULL,log); fprintf(stderr,"Vert: %s\n",log); exit(1);}

    GLuint frag = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(frag, 1, &fsrc, NULL);
    glCompileShader(frag);
    glGetShaderiv(frag, GL_COMPILE_STATUS, &ok);
    if(!ok){char log[512]; glGetShaderInfoLog(frag,512,NULL,log); fprintf(stderr,"Frag: %s\n",log); exit(1);}

    GLuint prog = glCreateProgram();
    glAttachShader(prog, vert);
    glAttachShader(prog, frag);
    glLinkProgram(prog);
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if(!ok){char log[512]; glGetProgramInfoLog(prog,512,NULL,log); fprintf(stderr,"Link: %s\n",log); exit(1);}

    glDeleteShader(vert);
    glDeleteShader(frag);
    return prog;
}

// Texture loading from PGM/PPM files
GLuint loadPPM(const char* path) {
    FILE* f = fopen(path, "rb");
    if(!f){fprintf(stderr,"Cannot open texture: %s\n",path); return 0;}
    char magic[3]; fscanf(f, "%2s", magic);
    int w, h, maxVal; fscanf(f, " %d %d %d ", &w, &h, &maxVal);
    bool isRGB = (magic[1]=='6');
    int channels = isRGB ? 3 : 1;
    unsigned char* data = new unsigned char[w*h*channels];
    fread(data, 1, w*h*channels, f);
    fclose(f);

    GLuint tex;
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    GLenum fmt = isRGB ? GL_RGB : GL_RED;
    glTexImage2D(GL_TEXTURE_2D, 0, fmt, w, h, 0, fmt, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
    delete[] data;
    return tex;
}

//Geometry: Sphere
struct Vertex { float x,y,z, nx,ny,nz, u,v; };

std::vector<Vertex> sphereVerts;
std::vector<unsigned int> sphereIdx;
std::vector<Vertex>   sphereLineIdx; //for wireframe lines

void buildSphere(int stacks, int sectors, float radius=0.5f) {
    sphereVerts.clear();
    sphereIdx.clear();

    for(int i=0;i<=stacks;i++){
        float phi = (float)i/stacks * M_PI; //0..pi
        for(int j=0;j<=sectors;j++){
            float theta = (float)j/sectors * 2.0f*M_PI;
            float x = sinf(phi)*cosf(theta);
            float y = cosf(phi);
            float z = sinf(phi)*sinf(theta);
            float u = (float)j/sectors;
            float v = (float)i/stacks;
            Vertex vert;
            vert.x=x*radius; vert.y=y*radius; vert.z=z*radius;
            vert.nx=x;  vert.ny=y;  vert.nz=z;
            vert.u=u;   vert.v=v;
            sphereVerts.push_back(vert);
        }
    }

    for(int i=0;i<stacks;i++){
        for(int j=0;j<sectors;j++){
            unsigned int a = i*(sectors+1)+j;
            unsigned int b = a+sectors+1;

            //Two triangles per quad
            sphereIdx.push_back(a);
            sphereIdx.push_back(b);
            sphereIdx.push_back(a+1);
            sphereIdx.push_back(b);
            sphereIdx.push_back(b+1);
            sphereIdx.push_back(a+1);
        }
    }
}

//Geometry: Floor plane made of NxN sub-quads
std::vector<Vertex> floorVerts;
std::vector<unsigned int> floorIdx;

void buildFloor(int subdivisions, float size=3.0f) {
    floorVerts.clear();
    floorIdx.clear();

    float half = size/2.0f;
    float step = size / subdivisions;

    for(int i=0;i<=subdivisions;i++){
        for(int j=0;j<=subdivisions;j++){
            float x = -half + j*step;
            float z = -half + i*step;
            float u = (float)j/subdivisions;
            float v = (float)i/subdivisions;

            Vertex vert;
            vert.x=x; vert.y=0; vert.z=z;
            vert.nx=0; vert.ny=1; vert.nz=0;
            vert.u=u; vert.v=v;
            floorVerts.push_back(vert);
        }
    }

    for(int i=0;i<subdivisions;i++){
        for(int j=0;j<subdivisions;j++){
            unsigned int a = i*(subdivisions+1)+j;
            unsigned int b = a+subdivisions+1;

            floorIdx.push_back(a);
            floorIdx.push_back(b);
            floorIdx.push_back(a+1);
            floorIdx.push_back(b);
            floorIdx.push_back(b+1);
            floorIdx.push_back(a+1);
        }
    }
}

//Wireframe

std::vector<unsigned int> makeWireframeLines(const std::vector<unsigned int>& triIdx) {
    std::vector<unsigned int> lines;
    for(size_t i=0; i+2<triIdx.size(); i+=3){
        lines.push_back(triIdx[i]);   lines.push_back(triIdx[i+1]);
        lines.push_back(triIdx[i+1]); lines.push_back(triIdx[i+2]);
        lines.push_back(triIdx[i+2]); lines.push_back(triIdx[i]);
    }
    return lines;
}

//GPU buffer upload helper
struct Mesh {
    GLuint vao=0, vbo=0, ebo=0, webo=0;
    int triCount=0, lineCount=0;
};

Mesh uploadMesh(const std::vector<Vertex>& verts,
                const std::vector<unsigned int>& idx)
{
    auto lines = makeWireframeLines(idx);
    Mesh m;
    m.triCount  = (int)idx.size();
    m.lineCount = (int)lines.size();

    glGenVertexArrays(1, &m.vao);
    glGenBuffers(1, &m.vbo);
    glGenBuffers(1, &m.ebo);
    glGenBuffers(1, &m.webo);

    glBindVertexArray(m.vao);

    glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
    glBufferData(GL_ARRAY_BUFFER, verts.size()*sizeof(Vertex), verts.data(), GL_STATIC_DRAW);

    //Triangle EBO
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, idx.size()*sizeof(unsigned int), idx.data(), GL_STATIC_DRAW);

    //Attribs: pos(0), normal(1), uv(2)
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,x));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,nx));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(Vertex),(void*)offsetof(Vertex,u));
    glEnableVertexAttribArray(2);

    glBindVertexArray(0);

    //Wire EBO (separate buffer, same VAO attribs)
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.webo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, lines.size()*sizeof(unsigned int), lines.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    return m;
}

void deleteMesh(Mesh& m){
    glDeleteBuffers(1,&m.ebo);
    glDeleteBuffers(1,&m.webo);
    glDeleteBuffers(1,&m.vbo);
    glDeleteVertexArrays(1,&m.vao);
    m={};
}

void drawMesh(const Mesh& m, bool wireframe) {
    glBindVertexArray(m.vao);
    if(!wireframe){
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ebo);
        glDrawElements(GL_TRIANGLES, m.triCount, GL_UNSIGNED_INT, 0);
    } else {
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.webo);
        glDrawElements(GL_LINES, m.lineCount, GL_UNSIGNED_INT, 0);
    }
    glBindVertexArray(0);
}

// Colour tables
struct Color3 { float r,g,b; };
static const Color3 COLOURS[] = {
    {1,0,0},{0,1,0},{0,0,1},{1,1,1},{0,0,0}, //R, G, B, White, Black,
    {1,1,0},{1,0.5f,0},{0.5f,0,1},{0,1,1},{0.5f,0.25f,0} //Yellow, Orange, Purple, Cyan, Brown,
};
static const int NUM_COLOURS = 10;
static const Color3 LIGHT_COLOURS[] = {
    {1,0,0},{0,1,0},{0,0,1},{1,1,1}, //R, G, B, White
    {1,1,0},{1,0.5f,0},{0.5f,0,1},{0,1,1},{1,0.75f,0.8f} //Yellow, Orange, Purple, Cyan, Pink
};
static const int NUM_LIGHT_COLOURS = 9;

//Global state
struct State {
    //Scene rotation
    float rotX=0, rotY=0, rotZ=0;

    //Light position 
    float lightX=0, lightY=0, lightZ=0;

    //Sphere
    int sphereStacks = 20, sphereSectors = 20;

    //Floor
    int floorSub = 20;

    //Colours
    int floorColIdx  = 3; //white
    int ballColIdx   = 3; //white
    int lightColIdx  = 3; //white

    //Alpha
    float globalAlpha = 0.5f;

    //Texture toggles
    bool useColourMap  = false;
    bool useDisplace   = false;
    bool useAlphaMap   = false;

    //Wireframe
    bool wireframe = false;

    void reset() {
        rotX=rotY=rotZ=0;
        lightX=lightY=lightZ=0;
        sphereStacks=sphereSectors=20;
        floorSub=20;
        floorColIdx=3; ballColIdx=3; lightColIdx=3;
        globalAlpha=0.5f;
        useColourMap=useDisplace=useAlphaMap=false;
        wireframe=false;
    }
} state;

Mesh sphereMesh, floorMesh;

void rebuildSphere(){
    if(sphereMesh.vao) deleteMesh(sphereMesh);
    buildSphere(state.sphereStacks, state.sphereSectors);
    sphereMesh = uploadMesh(sphereVerts, sphereIdx);
}
void rebuildFloor(){
    if(floorMesh.vao) deleteMesh(floorMesh);
    buildFloor(state.floorSub);
    floorMesh = uploadMesh(floorVerts, floorIdx);
}

// Keyboard
double lastWireToggle = -1.0;

void keyCallback(GLFWwindow* win, int key, int scancode, int action, int mods) {
    if(action != GLFW_PRESS && action != GLFW_REPEAT) return;

    float ROT_STEP   = 0.05f;
    float LIGHT_STEP = 0.05f;

    switch(key){
        //Rotations
        case GLFW_KEY_W: state.rotX += ROT_STEP; break;
        case GLFW_KEY_S: state.rotX -= ROT_STEP; break;
        case GLFW_KEY_A: state.rotY += ROT_STEP; break;
        case GLFW_KEY_D: state.rotY -= ROT_STEP; break;
        case GLFW_KEY_E: state.rotZ += ROT_STEP; break;
        case GLFW_KEY_Q: state.rotZ -= ROT_STEP; break;

        //Light translation
        case GLFW_KEY_UP:    state.lightY += LIGHT_STEP; break;
        case GLFW_KEY_DOWN:  state.lightY -= LIGHT_STEP; break;
        case GLFW_KEY_LEFT:  state.lightX -= LIGHT_STEP; break;
        case GLFW_KEY_RIGHT: state.lightX += LIGHT_STEP; break;
        case GLFW_KEY_PERIOD: // >
            if(mods & GLFW_MOD_SHIFT) state.lightZ += LIGHT_STEP; break;
        case GLFW_KEY_COMMA: // <
            if(mods & GLFW_MOD_SHIFT) state.lightZ -= LIGHT_STEP; break;
        //also handle without shift in case
        case GLFW_KEY_PAGE_UP:   state.lightZ += LIGHT_STEP; break;
        case GLFW_KEY_PAGE_DOWN: state.lightZ -= LIGHT_STEP; break;

        //Alpha
        case GLFW_KEY_EQUAL: // +
            state.globalAlpha = fminf(1.0f, state.globalAlpha + 0.05f); break;
        case GLFW_KEY_MINUS: // -
            state.globalAlpha = fmaxf(0.0f, state.globalAlpha - 0.05f); break;

        //Texture toggles
        case GLFW_KEY_B: state.useColourMap = !state.useColourMap; break;
        case GLFW_KEY_N: state.useDisplace  = !state.useDisplace;  rebuildSphere(); break;
        case GLFW_KEY_M: state.useAlphaMap  = !state.useAlphaMap;  break;

        //Sphere vertex count
        case GLFW_KEY_I:
            state.sphereStacks  = fmin(100, state.sphereStacks+2);
            state.sphereSectors = state.sphereStacks;
            rebuildSphere(); break;
        case GLFW_KEY_O:
            state.sphereStacks  = fmax(4, state.sphereStacks-2);
            state.sphereSectors = state.sphereStacks;
            rebuildSphere(); break;

        //Floor vertex count
        case GLFW_KEY_K:
            state.floorSub = fmin(100, state.floorSub+2); rebuildFloor(); break;
        case GLFW_KEY_L:
            state.floorSub = fmax(2,   state.floorSub-2); rebuildFloor(); break;

        //Floor colour
        case GLFW_KEY_1:
            state.floorColIdx = (state.floorColIdx+1) % NUM_COLOURS; break;
        case GLFW_KEY_2:
            state.floorColIdx = (state.floorColIdx-1+NUM_COLOURS) % NUM_COLOURS; break;

        //Ball colour
        case GLFW_KEY_3:
            state.ballColIdx = (state.ballColIdx+1) % NUM_COLOURS; break;
        case GLFW_KEY_4:
            state.ballColIdx = (state.ballColIdx-1+NUM_COLOURS) % NUM_COLOURS; break;

        //Light colour
        case GLFW_KEY_5:
            state.lightColIdx = (state.lightColIdx+1) % NUM_LIGHT_COLOURS; break;
        case GLFW_KEY_6:
            state.lightColIdx = (state.lightColIdx-1+NUM_LIGHT_COLOURS) % NUM_LIGHT_COLOURS; break;

        //Wireframe
        case GLFW_KEY_ENTER: {
            double now = glfwGetTime();
            if(now - lastWireToggle > 0.3) {
                state.wireframe = !state.wireframe;
                lastWireToggle = now;
            }
            break;
        }

        //Reset
        case GLFW_KEY_SPACE:
            state.reset();
            rebuildSphere();
            rebuildFloor();
            break;

        default: break;
    }
}

//Uniform setters
void setMat4(GLuint prog, const char* name, const Mat4& m){
    glUniformMatrix4fv(glGetUniformLocation(prog,name),1,GL_FALSE,m.m);
}
void setVec3(GLuint prog, const char* name, float r, float g, float b){
    glUniform3f(glGetUniformLocation(prog,name),r,g,b);
}
void setInt(GLuint prog, const char* name, int v){
    glUniform1i(glGetUniformLocation(prog,name),v);
}
void setFloat(GLuint prog, const char* name, float v){
    glUniform1f(glGetUniformLocation(prog,name),v);
}
void setBool(GLuint prog, const char* name, bool v){
    glUniform1i(glGetUniformLocation(prog,name), v?1:0);
}



int main(){
    if(!glfwInit()){ fprintf(stderr,"GLFW init failed\n"); return -1; }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR,3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR,3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* win = glfwCreateWindow(900,700, STUDENT_NUMBER, NULL, NULL);
    if(!win){ fprintf(stderr,"Window creation failed\n"); glfwTerminate(); return -1; }
    glfwMakeContextCurrent(win);

    glewExperimental = GL_TRUE;
    if(glewInit()!=GLEW_OK){ fprintf(stderr,"GLEW init failed\n"); return -1; }

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glfwSetKeyCallback(win, keyCallback);

    //Load shaders
    GLuint sphereProg = loadShader("shaders/sphereVert.glsl","shaders/sphereFrag.glsl");
    GLuint floorProg  = loadShader("shaders/floorVert.glsl", "shaders/floorFrag.glsl");

    //Load textures
    GLuint texColour = loadPPM("colour_map.ppm");
    GLuint texDisp   = loadPPM("displacement_map.pgm");
    GLuint texAlpha  = loadPPM("alpha_map.pgm");

    //Build geometry
    rebuildSphere();
    rebuildFloor();

    //Camera
    glm::vec3 camPos   = glm::vec3(0,2,3);
    glm::vec3 camTarget= glm::vec3(0,0,0);
    glm::vec3 camUp    = glm::vec3(0,1,0);

    Mat4 floorModel = translate(0,0,0);
    Mat4 sphereModel= translate(0,0.5f,0);

    while(!glfwWindowShouldClose(win)){
        glfwPollEvents();

        int fw,fh; glfwGetFramebufferSize(win,&fw,&fh);
        glViewport(0,0,fw,fh);
        glClearColor(0.1f,0.1f,0.15f,1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //Matrices
        Mat4 proj = perspective(0.7854f, (float)fw/fh, 0.1f, 100.0f);
        Mat4 view = lookAt(camPos, camTarget, camUp);

        //Scene rotation applied to both objects
        Mat4 sceneRot = mat4Mul(rotateZ(state.rotZ),
                        mat4Mul(rotateY(state.rotY),
                                rotateX(state.rotX)));

        Mat4 floorFinal  = mat4Mul(sceneRot, floorModel);
        Mat4 sphereFinal = mat4Mul(sceneRot, sphereModel);

        //Light position starts at ball centre (0,0.5,0) + local offset, then rotates with scene
        glm::vec4 localLight(state.lightX, 0.5f + state.lightY, state.lightZ, 1.0f);
        
        //Apply scene rotation to get world-space light position
        //multiply sceneRot * localLight
        glm::vec4 wl;
        for(int i=0;i<4;i++){
            wl[i]=0;
            for(int j=0;j<4;j++) wl[i]+=sceneRot.m[j*4+i]*localLight[j];
        }
        glm::vec3 lightWorldPos(wl.x,wl.y,wl.z);

        Color3 bc = COLOURS[state.ballColIdx];
        Color3 fc = COLOURS[state.floorColIdx];
        Color3 lc = LIGHT_COLOURS[state.lightColIdx];

        //Draw floor as opaque then lit by point light
        glDepthMask(GL_TRUE);
        glUseProgram(floorProg);
        setMat4(floorProg,"model",      floorFinal);
        setMat4(floorProg,"view",       view);
        setMat4(floorProg,"projection", proj);
        setVec3(floorProg,"floorColour", fc.r,fc.g,fc.b);
        setVec3(floorProg,"lightPos",    lightWorldPos.x,lightWorldPos.y,lightWorldPos.z);
        setVec3(floorProg,"lightColour", lc.r,lc.g,lc.b);
        setVec3(floorProg,"ballColour",  bc.r,bc.g,bc.b);
        setFloat(floorProg,"ambientStrength", 0.15f);
        setFloat(floorProg,"lightConstant",   1.0f);
        setFloat(floorProg,"lightLinear",     0.35f);
        setFloat(floorProg,"lightQuadratic",  0.44f);
        drawMesh(floorMesh, state.wireframe);

        //Draw sphere as translucent, drawn after floor
        glDepthMask(GL_FALSE);
        glUseProgram(sphereProg);
        setMat4(sphereProg,"model",       sphereFinal);
        setMat4(sphereProg,"view",        view);
        setMat4(sphereProg,"projection",  proj);

        //Textures
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texColour);
        setInt(sphereProg,"colourMap", 0);

        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, texDisp);
        setInt(sphereProg,"displacementMap", 1);

        glActiveTexture(GL_TEXTURE2);
        glBindTexture(GL_TEXTURE_2D, texAlpha);
        setInt(sphereProg,"alphaMap", 2);

        setBool(sphereProg,"useColourMap",  state.useColourMap);
        setBool(sphereProg,"useDisplacement",state.useDisplace);
        setBool(sphereProg,"useAlphaMap",   state.useAlphaMap);
        setFloat(sphereProg,"displacementStrength", 0.05f);
        setFloat(sphereProg,"globalAlpha",  state.globalAlpha);
        setVec3(sphereProg,"ballColour",    bc.r,bc.g,bc.b);
        setVec3(sphereProg,"ambientColour", 1,1,1);
        setFloat(sphereProg,"ambientStrength", 0.3f);

        drawMesh(sphereMesh, state.wireframe);
        glDepthMask(GL_TRUE);

        glfwSwapBuffers(win);
    }

    deleteMesh(sphereMesh);
    deleteMesh(floorMesh);
    glDeleteProgram(sphereProg);
    glDeleteProgram(floorProg);
    glDeleteTextures(1,&texColour);
    glDeleteTextures(1,&texDisp);
    glDeleteTextures(1,&texAlpha);

    glfwTerminate();
    return 0;
}
