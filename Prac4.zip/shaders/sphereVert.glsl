#version 330 core

layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aTexCoord;

out vec3 FragPos;
out vec3 Normal;
out vec2 TexCoord;
out vec3 OrigPos;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

uniform sampler2D displacementMap;
uniform bool useDisplacement;
uniform float displacementStrength;

void main()
{
    vec3 pos = aPos;
    vec3 norm = aNormal;

    if (useDisplacement) {
        float disp = texture(displacementMap, aTexCoord).r; //displace inward where dimples are, < 1.0 means dimple
        float offset = (disp - 1.0) * displacementStrength;
        pos = aPos + norm * offset;
    }

    OrigPos = aPos;
    FragPos = vec3(model * vec4(pos, 1.0));
    Normal  = mat3(transpose(inverse(model))) * norm;
    TexCoord = aTexCoord;

    gl_Position = projection * view * vec4(FragPos, 1.0);
}
