#version 330 core

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoord;

out vec4 FragColor;

uniform vec3 floorColour;
uniform vec3 lightPos;    //world-space position of internal light
uniform vec3 lightColour;
uniform vec3 ballColour;  //glass colour changes light

//Point light constants
uniform float lightConstant;
uniform float lightLinear;
uniform float lightQuadratic;

uniform float ambientStrength;

void main()
{
    vec3 norm = normalize(Normal);
    vec3 lightDir = normalize(lightPos - FragPos);

    vec3 ambient = ambientStrength * floorColour;

    float diff = max(dot(norm, lightDir), 0.0); //diffuse

    float distance    = length(lightPos - FragPos);
    float attenuation = 1.0 / (lightConstant + lightLinear * distance + lightQuadratic * (distance * distance));

    vec3 combinedLight = lightColour * ballColour;

    vec3 diffuse = diff * combinedLight * floorColour * attenuation;

    vec3 result = ambient + diffuse;
    FragColor = vec4(result, 1.0);
}
