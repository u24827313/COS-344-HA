#version 330 core

in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoord;
in vec3 OrigPos;

out vec4 FragColor;

uniform sampler2D colourMap;
uniform sampler2D alphaMap;

uniform bool useColourMap;
uniform bool useAlphaMap;

uniform vec3  ballColour;
uniform float globalAlpha;

uniform vec3 ambientColour;
uniform float ambientStrength;

void main()
{
    vec3 baseCol = ballColour;
    if (useColourMap) {
        vec3 texCol = texture(colourMap, TexCoord).rgb; //the texture encodes a grey pattern (dimples darker)
        //apply it as a multiplier over the ball colour
        baseCol = ballColour * texCol * 1.2; //slight brightness boost
    }

    //Ambient lighting so the ball is visible
    vec3 lit = ambientColour * ambientStrength * baseCol + baseCol * (1.0 - ambientStrength);

    //Alpha
    float alpha = globalAlpha;
    if (useAlphaMap) {
        float maskVal = texture(alphaMap, TexCoord).r; //0=dimples = transparent, 1=surface = opaque
        //dimple regions use globalAlpha, surface is fully opaque
        alpha = mix(globalAlpha, 1.0, maskVal);
    }

    FragColor = vec4(lit, alpha);
}
