Keyboard Controls

Rotation
W = Rotate scene around X-axis (positive)
S = Rotate scene around X-axis (negative)
A = Rotate scene around Y-axis (positive)
D = Rotate scene around Y-axis (negative)
E = Rotate scene around Z-axis (positive)
Q = Rotate scene around Z-axis (negative)

Translation
↑ Arrow = Move light +Y 
↓ Arrow = Move light -Y 
← Arrow = Move light -X 
→ Arrow = Move light +X 
Page Up / > = Move light +Z 
Page Down / < = Move light -Z

Alpha
+ = Increase glass alpha (more opaque)
- = Decrease glass alpha (more transparent)

Texture Maps
B = Toggle colour texture map (dimple shading)
N = Toggle displacement texture map (surface dimples)
M = Toggle alpha texture map (dimples transparent)

Vertex Count
I = Increase sphere vertices
O = Decrease sphere vertices
K = Increase floor vertices 
L = Decrease floor vertices 

Colours
1 = Cycle floor colour forward 
2 = Cycle floor colour backward 
3 = Cycle ball colour forward 
4 = Cycle ball colour backward 
5 = Cycle light colour forward 
6 = Cycle light colour backward 

Other
Enter = Toggle wireframe
Space = Reset scene to initial state

Colour Cycle Order
For floor and ball: Red → Green → Blue → White → Black → Yellow → Orange → Purple → Cyan → Brown  
For light: Red → Green → Blue → White → Yellow → Orange → Purple → Cyan → Pink

Algorithm
A hexagonal grid of circles is tiled across UV space `[0,1]²`:
- Grid: 22×22 cells with alternating row offset (hex packing)
- Each cell has a circular dimple of radius = 38% of cell size
- Each texel's UV coordinate is tested against all neighbouring cell centres
- The nearest dimple centre distance determines whether the texel is "dimple" or "surface"

colour_map.ppm
- Surface pixels → light grey (220, 220, 220)
- Dimple pixels → dark grey (120–180), smoothly darkened toward the centre (linear interpolation on distance)
- Applied as a multiplicative colour modifier over the ball colour

displacement_map.pgm
- Surface pixels → 255 (maximum height, no displacement)
- Dimple pixels → lower value using cosine falloff: `height = 255 × (1 - 0.6 × cos_depth)`
- Cosine provides a smooth bowl-shaped indentation
- In the vertex shader, vertices are displaced along their normal by `(height - 1.0) × strength`

alpha_map.pgm
- Surface pixels → 255 (fully opaque)
- Dimple pixels → 0 (transparent), with a slight feather at the edge (10% of radius)
- In the fragment shader: dimple regions use `globalAlpha`, surface regions are fully opaque