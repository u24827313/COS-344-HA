#ifndef MATHS_HPP
#define MATHS_HPP

#include <cmath>
#include <iostream>

struct Vec3
{
    float x, y, z; //Cartesian planes of vector. x=l/r, y=u/d, z=n/f

    Vec3(float x=0, float y=0, float z=0) : x(x), y(y), z(z) {} //Default constructor with all being 0 to start

    Vec3 operator+(const Vec3& obj) const { 
        return {x+obj.x, y+obj.y, z+obj.z}; 
    } //Used for direction vectors

    Vec3 operator-(const Vec3& obj) const { 
        return {x-obj.x, y-obj.y, z-obj.z};
    } //used to get forward direction (center - eye)
    Vec3 operator*(float scalar) { 
        return {x*scalar, y*scalar, z*scalar}; 
    } //Scaling direction vector by any length

    float dotProduct(const Vec3& obj) const {
        return x*obj.x + y*obj.y + z*obj.z;
    } //Projects eye pos onto each camer axis to compute translation part of view matrix

    Vec3 crossProduct(const Vec3& obj) const {
        return {
            y*obj.z - z*obj.y, //new X
            z*obj.x - x*obj.z, //new Y
            x*obj.y - y*obj.x  //newZ
        };
    } //Build orthonormal base for camera

    float length() const {
        return std::sqrt(x*x + y*y + z*z);
    }

    Vec3 normalise() const {
        float len= length();

        if (len <= 0) { //No division by 0
            return {0, 0, 0};
        }

        return {x/len, y/len, z/len}; //Normalised unit vector
    }
};

struct Mat4 {
    float mat[4][4]; 
    // mat[0][0] mat[0][1] mat[0][2] mat[0][3]
    // mat[1][0] mat[1][1] mat[1][2] mat[1][3]
    // mat[2][0] mat[2][1] mat[2][2] mat[2][3]
    // mat[3][0] mat[3][1] mat[3][2] mat[3][3]

    void identityMat() {
        for (int i=0; i<4; i++) {
            for (int j=0; j<4; j++) {
                if (i == j) {
                    mat[i][j] = 1.0f;
                } else {
                    mat[i][j] = 0.0f;
            
                }
            }
        }
    } //Makes an identity Matrix

    Mat4() { identityMat(); } //Default matrix = identity matrix

    void emptyOut() {
        for (int i=0; i<4; i++) {
            for (int j=0; j<4; j++) {
                mat[i][j] = 0.0f;
            }
        }
    } //Use to init result matrix for accumulation and for perspective matrix

    Mat4 operator*(const Mat4& B) {
        Mat4 result; 
        result.emptyOut(); //empty when we do += for sums

        for (int i=0; i<4; i++) { //columns
            for (int j=0; j<4; j++) { //rows
                for (int k=0; k<4; k++) { //dot product of left row and right column
                    result.mat[i][j] += mat[i][k] * B.mat[k][j]; //left mat's row * right mat's col (row j, col k / row k, col i)
                }
            }
        }

        return result;
    } //Matrix multplication (This * other = A*B)

    const float* pointer() const {
        return &mat[0][0];
    } //Return pointer to first float of array

    // Transform Matrices

    static Mat4 identity() {
        Mat4 Mat; //Default calls identityMat
        return Mat; //used for readability
    }

    static Mat4 translation(float x, float y, float z) {
        Mat4 Mat; //start off with identity

        Mat.mat[0][3] = x; //homogenous coord
        Mat.mat[1][3] = y; //homogenous coord
        Mat.mat[2][3] = z; //homogenous coord

        return Mat; //transformed matrix
    }

    static Mat4 scale(float x, float y, float z) {
        Mat4 Mat;

        Mat.mat[0][0] = x; //scale x
        Mat.mat[1][1] = y; //scale y
        Mat.mat[2][2] = z; //scale z

        return Mat;
    }

    static Mat4 rotateX(float angle) {
        Mat4 Mat;

        float cosine = std::cos(angle);
        float sine = std::sin(angle);

        Mat.mat[1][1] = cosine;
        Mat.mat[1][2] = -sine;
        Mat.mat[2][1] = sine;
        Mat.mat[2][2] = cosine;

        return Mat;
    }

    static Mat4 rotateY(float angle) {
        Mat4 Mat;

        float cosine = std::cos(angle);
        float sine = std::sin(angle);

        Mat.mat[0][0] = cosine;
        Mat.mat[2][0] = -sine;
        Mat.mat[0][2] = sine;
        Mat.mat[2][2] = cosine;

        return Mat;
    }

    static Mat4 rotateZ(float angle) {
        Mat4 Mat;

        float cosine = std::cos(angle);
        float sine = std::sin(angle);

        Mat.mat[0][0] = cosine;
        Mat.mat[0][1] = -sine;
        Mat.mat[1][0] = sine;
        Mat.mat[1][1] = cosine;

        return Mat;
    }

    static Mat4 rotateAAAxis(Vec3 axis, float angle) {
        axis = axis.normalise();

        float cosine = std::cos(angle);
        float sine = std::sin(angle);
        float minus = 1.0f - cosine; //1 minus cosine
        float x = axis.x; 
        float y = axis.y;
        float z = axis.z;

        Mat4 Mat;
        //   R = t*x*x+c    t*x*y-s*z  t*x*z+s*y  0
        //       t*x*y+s*z  t*y*y+c    t*y*z-s*x  0
        //       t*x*z-s*y  t*y*z+s*x  t*z*z+c    0
        //       0          0          0           1

        Mat.mat[0][0] = minus*x*x+cosine;
        Mat.mat[1][0] = minus*x*y-sine*z;
        Mat.mat[2][0] = minus*x*z+sine*y;

        Mat.mat[0][1] = minus*x*y+sine*z;
        Mat.mat[1][1] = minus*y*y+cosine;
        Mat.mat[2][1] = minus*y*z-sine*x;

        Mat.mat[0][2] = minus*x*z-sine*y;
        Mat.mat[1][2] = minus*y*z+sine*x; 
        Mat.mat[2][2] = minus*z*z+cosine;

        return Mat;
    } //More general than x,y or z axis like rotor

    static Mat4 perspective(float FOV, float ratio, float near, float far) {
        Mat4 Mat;
        Mat.emptyOut();

        float focal = 1.0f / std::tan(FOV * 0.5f);

        //   [ f/a  0    0              0    ]
        //   [ 0    f    0              0    ]
        //   [ 0    0   (f+n)/(n-f)    -1    ]
        //   [ 0    0   (2fn)/(n-f)     0    ]

        Mat.mat[0][0] = focal / ratio;
        Mat.mat[1][1] = focal; 
        Mat.mat[2][2] = (far + near) / (near - far); 
        Mat.mat[2][3] = (2.0f * far * near) / (near - far); 
        Mat.mat[3][2] = -1.0f; 

        return Mat;
    } //Perspective projection

    static Mat4 look(Vec3 eye, Vec3 centre, Vec3 up) { //cam pos in world space, point cam looks at, world's up direction
        Vec3 forward = (centre - eye).normalise(); //forward direction from eye to centre
        Vec3 right = forward.crossProduct(up).normalise(); //right direction, perpendicular to both forward and up
        Vec3 u = right.crossProduct(forward); //true up direction, perpendicular to forward and right

        Mat4 Mat;

        Mat.mat[0][0] = right.x;    Mat.mat[0][1] = right.y;    Mat.mat[0][2] = right.z; //right axis rotation in row 0
        Mat.mat[1][0] = u.x;        Mat.mat[1][1] = u.y;        Mat.mat[1][2] = u.z; //up axis rotation in row 1
        Mat.mat[2][0] = -forward.x; Mat.mat[2][1] = -forward.y; Mat.mat[2][2] = -forward.z; //backward axis rotation in row 2

        //Translation = fourth col for translation
        Mat.mat[0][3] = -right.dotProduct(eye); //translate along right axis to move eye to origin
        Mat.mat[1][3] = -u.dotProduct(eye); //translate along up axis to move eye to origin
        Mat.mat[2][3] = forward.dotProduct(eye); //translate along forward axis to move eye to origin, not negative cause already handled in rotation

        return Mat;
    } //Transforms coords into camera space coords
};

#endif