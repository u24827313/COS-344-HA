#ifndef SHAPES_HPP
#define SHAPES_HPP

#include <vector>
#include <cmath>

/*
    Every builder:
        VBufer& verts - flat vertex array (x,y,z,r,g,b per vertex)
        IBuffer& solid - index for GL_TRIANGLES (solid rendering)
        IBuffer& wire - index pairs for GL_LINES (wireframe)
    Append without clearing first so multiple builders call for same buffers to build entire mesh group before uploading it to GPU at once    
*/

struct Colour {
    float r, g, b; //simple RGB with each channel betwwen 0->1
};

namespace Palette { //Group functions under common name
    //Course colours
    inline Colour grass() {
        return {0.18f, 0.60f, 0.20f};
    }

    inline Colour darkGrass() {
        return {0.12f, 0.45f, 0.14f};
    }

    inline Colour starting() {
        return {0.20f, 0.20f, 0.80f};
    }

    inline Colour wall() {
        return {0.35f, 0.25f, 0.15f};
    }

    inline Colour hole() {
        return {0.05f, 0.05f, 0.05f};
    }

    //Windmill colours
    inline Colour stone() {
        return {0.87f, 0.83f, 0.72f};
    }

    inline Colour darkStone() {
        return {0.70f, 0.65f, 0.55f};
    }

    inline Colour darkRoof() {
        return {0.30f, 0.25f, 0.20f};
    }

    //Blade colours
    inline Colour blade() {
        return {0.85f, 0.15f, 0.10f};
    }

    inline Colour darkBlade() {
        return {0.60f, 0.08f, 0.05f};
    }

    //Axle colours
    inline Colour metal() {
        return {0.72f, 0.72f, 0.75f};
    }

    inline Colour darkMetal() {
        return {0.50f, 0.50f, 0.53f};
    }

    //Decoration colours
    inline Colour tree() { 
        return {0.10f, 0.50f, 0.10f}; 
    }

    inline Colour trunk() { 
        return {0.40f, 0.25f, 0.10f}; 
    }

    inline Colour flagPole() { 
        return {0.80f, 0.80f, 0.80f}; 
    }

    inline Colour flagRed() { 
        return {0.90f, 0.10f, 0.10f}; 
    }

    inline Colour sand() { 
        return {0.90f, 0.82f, 0.55f}; 
    }
}

//Buffers
using VBuffer = std::vector<float>; //Vertex buffer, [x, y, z, r, g, b] format

using IBuffer = std::vector<unsigned int>; //Index buffer, each int is index in VBuffer, which vertex to use

//Vertex and Index helper funcs
static inline unsigned int pushVertex(VBuffer& v, float x, float y, float z, Colour c) {
    unsigned int index = (unsigned int)(v.size() / 6); //Calc index new vert will have

    v.push_back(x);
    v.push_back(y);
    v.push_back(z);
    v.push_back(c.r);
    v.push_back(c.g);
    v.push_back(c.b);

    return index;
} //Appends vertex to buffer and returns its index

static inline void quad(IBuffer& index, unsigned int a, unsigned int b, unsigned int c, unsigned int d) {
    //   d ─── c
    //   │   / │
    //   │  /  │
    //   a ─── b

    index.push_back(a);
    index.push_back(b);
    index.push_back(c); //first triangle

    index.push_back(a);
    index.push_back(c);
    index.push_back(d); //second triangle
} //2 triangles into quad into index buffer

static inline void quadWire(IBuffer& index, unsigned int a, unsigned int b, unsigned int c, unsigned int d) {
    index.push_back(a);
    index.push_back(b);

    index.push_back(b);
    index.push_back(c);

    index.push_back(c); 
    index.push_back(d);

    index.push_back(d);
    index.push_back(a);
    
    index.push_back(a);
    index.push_back(c);
}

struct Cuboid {
    unsigned int baseVertex;
    unsigned int countVertex;
    unsigned int indexOffset;
    unsigned int countIndex;
    unsigned int wireOffset;
    unsigned int countWires;
};

inline Cuboid makeCuboid(VBuffer& verts, IBuffer& solid, IBuffer& wire, float w, float h, float d, Colour top, Colour side, Colour bottom_col, float offx=0, float offy=0, float offz=0) {
    Cuboid result;
    result.baseVertex  = (unsigned int)(verts.size() / 6); //starting vertex index before do anything

    result.indexOffset = (unsigned int)(solid.size()); //starting pos in solid index buffer

    result.wireOffset  = (unsigned int)(wire.size()); //starting pos in wireframe index buffer

    float hw = w * 0.5f;  //half width - X offset from centre to each wall
    float hd = d * 0.5f;  //half depth - Z offset from centre to each wall

    float x0 = offx - hw;   //left face X coordinate  
    float x1 = offx + hw;   //right face X coordinate 
    float y0 = offy;        //bottom face Y coordinate
    float y1 = offy + h;    //top face Y coordinate
    float z0 = offz - hd;   //back face Z coordinate  
    float z1 = offz + hd;   //front face Z coordinate 

    //Bottom face
    auto bottom0 = pushVertex(verts, x0, y0, z1, bottom_col); //front-left corner
    auto bottom1 = pushVertex(verts, x1, y0, z1, bottom_col); //front-right corner
    auto bottom2 = pushVertex(verts, x1, y0, z0, bottom_col); //back-right corner
    auto bottom3 = pushVertex(verts, x0, y0, z0, bottom_col); //back-left corner

    //Top face
    auto top0 = pushVertex(verts, x0, y1, z1, top); //front-left corner at top height
    auto top1 = pushVertex(verts, x1, y1, z1, top); //front-right corner at top height
    auto top2 = pushVertex(verts, x1, y1, z0, top); //back-right corner at top height
    auto top3 = pushVertex(verts, x0, y1, z0, top); // back-left corner at top height

    //Front face
    auto front0 = pushVertex(verts, x0, y0, z1, side); // bottom-left at front face
    auto front1 = pushVertex(verts, x1, y0, z1, side); // bottom-right at front face
    auto front2 = pushVertex(verts, x1, y1, z1, side); // top-right at front face
    auto front3 = pushVertex(verts, x0, y1, z1, side); // top-left at front face

    //Back face - winding reversed so normal faces outward
    auto back0 = pushVertex(verts, x1, y0, z0, side); // bottom-right at back face (from outside, left)
    auto back1 = pushVertex(verts, x0, y0, z0, side); // bottom-left at back face (from outside, right)
    auto back2 = pushVertex(verts, x0, y1, z0, side); // top-left at back face (from outside,  right)
    auto back3 = pushVertex(verts, x1, y1, z0, side); // top-right at back face (from outside, left)

    //Left face - facing toward -X
    auto left0 = pushVertex(verts, x0, y0, z0, side); // bottom-back at left face
    auto left1 = pushVertex(verts, x0, y0, z1, side); // bottom-front at left face
    auto left2 = pushVertex(verts, x0, y1, z1, side); // top-front at left face
    auto left3 = pushVertex(verts, x0, y1, z0, side); // top-back at left face

    //Right face - facing toward +X
    auto right0 = pushVertex(verts, x1, y0, z1, side); // bottom-front at right face
    auto right1 = pushVertex(verts, x1, y0, z0, side); // bottom-back at right face
    auto right2 = pushVertex(verts, x1, y1, z0, side); // top-back at right face
    auto right3 = pushVertex(verts, x1, y1, z1, side); // top-front at right face

    //Push solid faces
    quad(solid, bottom0, bottom3, bottom2, bottom1); 
    quad(solid, top0, top1, top2, top3);
    quad(solid, front0, front1, front2, front3);
    quad(solid, back0, back1, back2, back3);
    quad(solid, left0, left1, left2, left3);
    quad(solid, right0, right1, right2, right3);

    //Push wireframe edges
    quadWire(wire, bottom0, bottom1, bottom2, bottom3); //bottom ring

    quadWire(wire, top0, top3, top2, top1); //top ring

    wire.push_back(bottom0); wire.push_back(top0); //front left corner
    wire.push_back(bottom1); wire.push_back(top1); //front right corner
    wire.push_back(bottom2); wire.push_back(top2); //back right corner
    wire.push_back(bottom3); wire.push_back(top3); //back left corner

    //These four vertical lines connect the bottom ring to the top ring

    //Fill struct
    result.countVertex = (unsigned int)(verts.size() / 6) - result.baseVertex; //Total vertices added, current count - count before started
    result.countIndex  = (unsigned int)(solid.size()) - result.indexOffset; //Total solid indices added
    result.countWires  = (unsigned int)(wire.size())  - result.wireOffset; //Total wireframe indices added

    return result;
}    


inline void makeTriPrism(VBuffer& verts, IBuffer& solid, IBuffer& wire, 
                           float ax, float ay, //corner A of triangle in local XY
                           float bx, float by, //corner B of triangle in local XY
                           float cx, float cy, //corner C of triangle in local XY
                           float z0, float z1, //front and back Z extents
                           Colour face, Colour side, float offx=0, float offy=0, float offz=0) {
    auto Af = pushVertex(verts, offx+ax, offy+ay, offz+z0, face); //front cap, corner A
    auto Bf = pushVertex(verts, offx+bx, offy+by, offz+z0, face); //front cap, corner B
    auto Cf = pushVertex(verts, offx+cx, offy+cy, offz+z0, face); //front cap, corner C
    auto Ab = pushVertex(verts, offx+ax, offy+ay, offz+z1, face); //back  cap, corner A
    auto Bb = pushVertex(verts, offx+bx, offy+by, offz+z1, face); //back  cap, corner B
    auto Cb = pushVertex(verts, offx+cx, offy+cy, offz+z1, face); //back  cap, corner C

    //Front triangle
    solid.push_back(Af); solid.push_back(Bf); solid.push_back(Cf);
    //Back triangle
    solid.push_back(Ab); solid.push_back(Cb); solid.push_back(Bb);

    //Side A–B
    auto saf = pushVertex(verts, offx+ax, offy+ay, offz+z0, side); //A at front
    auto sbf = pushVertex(verts, offx+bx, offy+by, offz+z0, side); //B at front
    auto sbb = pushVertex(verts, offx+bx, offy+by, offz+z1, side); //B at back
    auto sab = pushVertex(verts, offx+ax, offy+ay, offz+z1, side); //A at back
    quad(solid, saf, sbf, sbb, sab);

    //Side B–C 
    auto tbf = pushVertex(verts, offx+bx, offy+by, offz+z0, side); //B at front
    auto tcf = pushVertex(verts, offx+cx, offy+cy, offz+z0, side); //C at front
    auto tcb = pushVertex(verts, offx+cx, offy+cy, offz+z1, side); //C at back
    auto tbb = pushVertex(verts, offx+bx, offy+by, offz+z1, side); //B at back
    quad(solid, tbf, tcf, tcb, tbb);

    // Side C–A (the edge from C back to A, extruded along Z)
    auto ucf = pushVertex(verts, offx+cx, offy+cy, offz+z0, side); //C at front
    auto uaf = pushVertex(verts, offx+ax, offy+ay, offz+z0, side); //A at front
    auto uab = pushVertex(verts, offx+ax, offy+ay, offz+z1, side); //A at back
    auto ucb = pushVertex(verts, offx+cx, offy+cy, offz+z1, side); //C at back
    quad(solid, ucf, uaf, uab, ucb);

    //Wireframe
    wire.push_back(Af); wire.push_back(Bf); //front triangle edge A→B
    wire.push_back(Bf); wire.push_back(Cf); //front triangle edge B→C
    wire.push_back(Cf); wire.push_back(Af); //front triangle edge C→A

    wire.push_back(Ab); wire.push_back(Bb); //back triangle edge A→B
    wire.push_back(Bb); wire.push_back(Cb); //back triangle edge B→C
    wire.push_back(Cb); wire.push_back(Ab); //back triangle edge C→A

    wire.push_back(Af); wire.push_back(Af); //vertical edge at corner A
    wire.push_back(Bf); wire.push_back(Bf); //vertical edge at corner B
    wire.push_back(Cf); wire.push_back(Cf); //vertical edge at corner C
}


inline void makeCylinder(VBuffer& verts, IBuffer& solid, IBuffer& wire, float radius, float height, int segs, Colour cap, Colour side, float offx=0, float offy=0, float offz=0) {
    //Centre vertices of the two caps
    auto bcCtr = pushVertex(verts, offx, offy, offz, cap); //Centre of bottom cap
    auto tcCtr = pushVertex(verts, offx, offy+height, offz, cap); //Centre of top cap

    //ring vertices for both caps
    std::vector<unsigned int> bot, top; //Two vectors to store the indices of the bottom and top ring vertices

    for (int i = 0; i < segs; i++) {
        float theta = (float)(2.0 * M_PI * i / segs); //theta = the angle of this ring vertex

        float x = radius * std::cos(theta); //X coordinate of this vertex on the circle

        float z = radius * std::sin(theta); //Z coordinate of this vertex on the circle

        bot.push_back(pushVertex(verts, offx+x, offy, offz+z, cap)); //Bottom ring vertex
        top.push_back(pushVertex(verts, offx+x, offy+height, offz+z, cap)); //Top ring vertex
    }

    //Bottom cap triangle fan
    for (int i = 0; i < segs; i++) {
        solid.push_back(bcCtr);              //vertex at the centre
        solid.push_back(bot[(i+1) % segs]);  //next ring vertex
        solid.push_back(bot[i]);             //current ring vertex
        //Three indices = one triangle
        //Each iteration creates one "slice" of the fan
    }

    //Top cap triangle fan
    for (int i = 0; i < segs; i++) {
        solid.push_back(tcCtr);              //vertex at the top centre
        solid.push_back(top[i]);             //current ring vertex
        solid.push_back(top[(i+1) % segs]); //next ring vertex
    }

    //Side quads (tube surface)
    //The curved side is approximated by 'segs' rectangular quads
    //Each quad connects one segment of the bottom ring to the corresponding segment of the top ring
    //push FRESH vertices with the side colour here rather than reusing cap ring vertices, because the side colour may differ from the cap colour
    for (int i = 0; i < segs; i++) {
        int j = (i + 1) % segs; //j = index of the next ring vertex (wrapp around at last segment)

        float th0 = (float)(2.0 * M_PI * i / segs); //th0 = angle at the left edge of this side quad
        float th1 = (float)(2.0 * M_PI * j / segs); //th1 = angle at the right edge of this side quad
        
        float x0 = radius * std::cos(th0);   //X at left edge
        float z0v = radius * std::sin(th0);  //Z at left edge
        float x1 = radius * std::cos(th1);   //X at right edge
        float z1v = radius * std::sin(th1);  //Z at right edge

        auto s0 = pushVertex(verts, offx+x0, offy,        offz+z0v, side); // bottom-left of quad
        auto s1 = pushVertex(verts, offx+x1, offy,        offz+z1v, side); // bottom-right of quad
        auto s2 = pushVertex(verts, offx+x1, offy+height, offz+z1v, side); // top-right of quad
        auto s3 = pushVertex(verts, offx+x0, offy+height, offz+z0v, side); // top-left of quad

        quad(solid, s0, s1, s2, s3);
    }

    //Wireframe
    for (int i = 0; i < segs; ++i) {
        wire.push_back(bot[i]); wire.push_back(bot[(i+1) % segs]); //One segment of the BOTTOM ring
        wire.push_back(top[i]); wire.push_back(top[(i+1) % segs]); //One segment of the TOP ring
        wire.push_back(bot[i]); wire.push_back(top[i]); // One VERTICAL line connecting bottom ring vertex i to top ring vertex i
    }
}

// Cylinder oriented along Z (height = length along Z)
inline void makeCylinderZ(VBuffer& verts, IBuffer& solid, IBuffer& wire,
                          float radius, float length, int segs,
                          Colour capFront, Colour capBack, Colour side,
                          float offx=0, float offy=0, float offz=0) {
    // Front and back centre vertices
    auto frontCtr = pushVertex(verts, offx, offy, offz + length*0.5f, capFront);
    auto backCtr  = pushVertex(verts, offx, offy, offz - length*0.5f, capBack);

    // Ring vertices at front and back planes
    std::vector<unsigned int> frontRing, backRing;
    for (int i = 0; i < segs; ++i) {
        float theta = (float)(2.0 * M_PI * i / segs);
        float x = radius * std::cos(theta);
        float y = radius * std::sin(theta);
        frontRing.push_back(pushVertex(verts, offx+x, offy+y, offz + length*0.5f, capFront));
        backRing.push_back( pushVertex(verts, offx+x, offy+y, offz - length*0.5f, capBack));
    }

    // Front cap (facing +Z)
    for (int i = 0; i < segs; i++) {
        solid.push_back(frontCtr);
        solid.push_back(frontRing[(i+1)%segs]);
        solid.push_back(frontRing[i]);
    }
    // Back cap (facing -Z) – reverse winding
    for (int i = 0; i < segs; i++) {
        solid.push_back(backCtr);
        solid.push_back(backRing[i]);
        solid.push_back(backRing[(i+1)%segs]);
    }

    // Side quads (extruded along Z)
    for (int i = 0; i < segs; i++) {
        int j = (i+1) % segs;
        float th0 = (float)(2.0 * M_PI * i / segs);
        float th1 = (float)(2.0 * M_PI * j / segs);
        float x0 = radius * std::cos(th0);
        float y0 = radius * std::sin(th0);
        float x1 = radius * std::cos(th1);
        float y1 = radius * std::sin(th1);

        auto s0 = pushVertex(verts, offx+x0, offy+y0, offz - length*0.5f, side); // back-left
        auto s1 = pushVertex(verts, offx+x1, offy+y1, offz - length*0.5f, side); // back-right
        auto s2 = pushVertex(verts, offx+x1, offy+y1, offz + length*0.5f, side); // front-right
        auto s3 = pushVertex(verts, offx+x0, offy+y0, offz + length*0.5f, side); // front-left
        quad(solid, s0, s1, s2, s3);
    }

    // Wireframe
    for (int i = 0; i < segs; ++i) {
        wire.push_back(frontRing[i]); wire.push_back(frontRing[(i+1)%segs]);
        wire.push_back(backRing[i]);  wire.push_back(backRing[(i+1)%segs]);
        wire.push_back(frontRing[i]); wire.push_back(backRing[i]);
    }
}


inline void makeCone(VBuffer& verts, IBuffer& solid, IBuffer& wire, float radius, float height, int segs, Colour cap, Colour side, float offx=0, float offy=0, float offz=0) {
    auto apex = pushVertex(verts, offx, offy+height, offz, side); //tip of cone, top centre
    auto capCtr = pushVertex(verts, offx, offy, offz, cap); //centre of the circular base cap

    //Generate base ring vertices
    std::vector<unsigned int> ring; //Stores the indices of all base ring vertices for use in the cap fan    

    for (int i = 0; i < segs; ++i) {
        float theta = (float)(2.0 * M_PI * i / segs); //Angle for this ring vertex, evenly spaced around the full circle
        float x = radius * std::cos(theta);
        float z = radius * std::sin(theta);

        ring.push_back(pushVertex(verts, offx+x, offy, offz+z, cap)); //Base ring vertex at ground level
    }

    //Base cap triangle fan
    for (int i = 0; i < segs; ++i) {
        solid.push_back(capCtr);
        solid.push_back(ring[(i+1) % segs]);
        solid.push_back(ring[i]);
        //Same fan pattern as the bottom cap of the cylinder
    }

    //Side triangles (each connects two base vertices to the apex)

    for (int i = 0; i < segs; ++i) {
        int j = (i + 1) % segs; //next ring segment index (wraps to 0 on the last iteration)

        //Angles for this pair of base vertices.
        float th0 = (float)(2.0 * M_PI * i / segs);
        float th1 = (float)(2.0 * M_PI * j / segs);
        
        //Left base vertex of this side triangle
        auto s0 = pushVertex(verts, offx + radius*std::cos(th0), offy, offz + radius*std::sin(th0), side);
        
        //Right base vertex of this side triangle, coloured as side
        auto s1 = pushVertex(verts, offx + radius*std::cos(th1), offy, offz + radius*std::sin(th1), side);
        
        //copy of the apex vertex for this triangle
        auto ap = pushVertex(verts, offx, offy+height, offz, side);

        solid.push_back(s0); solid.push_back(s1); solid.push_back(ap);
        //Three indices = one side triangle
    }

    //Wireframe: base ring + lines from ring to apex

    for (int i = 0; i < segs; ++i) {
        wire.push_back(ring[i]); wire.push_back(ring[(i+1) % segs]); //One segment of the base ring

        wire.push_back(ring[i]); wire.push_back(apex); //One line from a ring vertex up to the apex
    }
}


inline void makeRect(VBuffer& verts, IBuffer& solid, IBuffer& wire, float w, float d, Colour col, float offx=0, float offy=0, float offz=0) {
    float hw = w * 0.5f; //half width
    float hd = d * 0.5f; //half depth

    auto v0 = pushVertex(verts, offx-hw, offy, offz-hd, col); //back-left  corner
    auto v1 = pushVertex(verts, offx+hw, offy, offz-hd, col); //back-right corner
    auto v2 = pushVertex(verts, offx+hw, offy, offz+hd, col); //front-right corner
    auto v3 = pushVertex(verts, offx-hw, offy, offz+hd, col); //front-left corner

    quad(solid, v0, v3, v2, v1);
    quadWire(wire, v0, v1, v2, v3);
}


inline void makeBladeRect(VBuffer& verts, IBuffer& solid, IBuffer& wire, float w, float h, float thickness, Colour front, Colour back, float offx=0, float offy=0, float offz=0) {
    makeCuboid(verts, solid, wire, w, h, thickness, front, front, back, offx, offy, offz);
}

#endif