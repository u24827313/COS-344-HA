#version 330 core

// ── Inputs from the vertex shader (interpolated across the triangle) ──────
// The names and types must EXACTLY match the 'out' variables in vertex.glsl.

in vec3 vColor;
// The interpolated per-vertex colour.  Since all corners of each face share
// the same colour in our geometry, this is effectively flat shading.

in vec3 vWorldPos;
// The fragment's position in world space.
// Available for lighting / fog calculations if you want them later.

in vec3 vNormal;
// The interpolated surface normal in world space.
// Currently a placeholder (hardcoded to (0,1,0) in the vertex shader).

// ── Output ────────────────────────────────────────────────────────────────
out vec4 FragColor;
// The final RGBA colour written to the framebuffer for this fragment.
// Components are in [0.0, 1.0]:  (red, green, blue, alpha).
// Alpha = 1.0 means fully opaque.

// ── Uniforms ──────────────────────────────────────────────────────────────
// These are all optional extras.  If you do not set them from the CPU,
// GLSL initialises uniforms to 0, so the fallback behaviour is noted below.

uniform int  uMode;
// Rendering mode switch.  Lets you toggle effects from the CPU without
// recompiling the shader.  Set with glUniform1i(modeLoc, value).
//   0 = flat vertex colour only           (default / fallback)
//   1 = flat colour + simple diffuse light
//   2 = flat colour + diffuse + distance fog
// If never set from the CPU, uMode = 0 and you get plain vertex colours —
// identical behaviour to the original inline shader.

uniform vec3 uLightPos;
// World-space position of a single point light.
// Only used when uMode >= 1.
// Set with glUniform3f(lightPosLoc, x, y, z).
// If not set, defaults to (0,0,0) — the world origin.

uniform vec3 uLightColor;
// RGB colour/intensity of the light.  (1,1,1) = white full-brightness.
// Only used when uMode >= 1.
// If not set, defaults to (0,0,0) — no light contribution (scene goes dark).
// Safe fallback when uMode = 0 since lighting is not applied in that mode.

uniform float uAmbient;
// Ambient light factor in [0.0, 1.0].
// Prevents faces pointing away from the light from being completely black.
// Only used when uMode >= 1.
// If not set, defaults to 0.0.  A value of 0.2 is a reasonable starting point.

uniform float uFogStart;
// World-space distance at which fog begins.  Only used when uMode = 2.
// If not set, defaults to 0.0 — fog starts immediately at the camera.

uniform float uFogEnd;
// World-space distance at which the scene is completely hidden by fog.
// If not set, defaults to 0.0 — divide-by-zero risk, so set this if using fog.

uniform vec3 uFogColor;
// The colour to blend toward as distance increases.  Typically the background
// clear colour so objects fade naturally into the sky.
// If not set, defaults to (0,0,0) — black fog.

uniform vec3 uCameraPos;
// World-space position of the camera.  Used to compute fragment distance for
// fog.  Set with glUniform3f(cameraPosLoc, eye.x, eye.y, eye.z).

void main() {

    // ── Mode 0: plain flat vertex colour (the original behaviour) ─────────
    if (uMode == 0) {
        FragColor = vec4(vColor, 1.0);
        // Exactly what the original inline shader did.
        // No lighting, no fog — just output the stored colour at full opacity.
        return;
        // Early return skips all other calculations.
    }

    // ── Shared lighting calculation (used by modes 1 and 2) ───────────────

    // Direction from this fragment's world position toward the light source.
    vec3 lightDir = normalize(uLightPos - vWorldPos);
    // normalize() scales the vector to unit length.
    // If uLightPos == vWorldPos (light inside the surface), this returns NaN,
    // but in practice the light should always be placed some distance away.

    vec3 normal = normalize(vNormal);
    // Normalise the interpolated normal.  Even if it was unit-length at each
    // vertex, interpolation across the triangle can change its length slightly.

    float diff = max(dot(normal, lightDir), 0.0);
    // Lambertian diffuse term: the cosine of the angle between the surface
    // normal and the light direction.
    //   dot(normal, lightDir) = cos(angle) when both are unit vectors.
    //   max(..., 0.0) clamps negative values (back-faces) to zero so they
    //   do not contribute negative light.

    float lighting = uAmbient + (1.0 - uAmbient) * diff;
    // Combine ambient and diffuse:
    //   uAmbient      = minimum brightness even on faces pointing away from light
    //   (1-uAmbient)*diff = additional brightness from the light direction
    // When diff=1.0 (face directly toward light), lighting = 1.0 (full bright).
    // When diff=0.0 (face perpendicular/away), lighting = uAmbient.

    vec3 litColor = vColor * uLightColor * lighting;
    // Apply the lighting factor to the vertex colour.
    // Also modulates by uLightColor so you can tint the light (e.g. warm orange).
    // With uLightColor = (1,1,1) and uAmbient = 0.2, faces pointing directly
    // at the light appear at full vertex colour; back-faces appear at 20%.

    // ── Mode 1: flat colour + diffuse lighting ────────────────────────────
    if (uMode == 1) {
        FragColor = vec4(litColor, 1.0);
        return;
    }

    // ── Mode 2: flat colour + diffuse lighting + distance fog ─────────────
    if (uMode == 2) {

        float dist = length(vWorldPos - uCameraPos);
        // Euclidean distance from the camera to this fragment in world space.

        float fogFactor = clamp((dist - uFogStart) / (uFogEnd - uFogStart), 0.0, 1.0);
        // Linear fog factor:
        //   0.0 = no fog (fragment is at or closer than uFogStart)
        //   1.0 = fully fogged (fragment is at or farther than uFogEnd)
        // clamp() keeps the value in [0,1] so fragments before uFogStart are
        // never darkened and fragments beyond uFogEnd are fully the fog colour.

        vec3 finalColor = mix(litColor, uFogColor, fogFactor);
        // mix(a, b, t) = a*(1-t) + b*t — standard linear interpolation.
        // At fogFactor=0: finalColor = litColor (no fog effect).
        // At fogFactor=1: finalColor = uFogColor (completely hidden by fog).

        FragColor = vec4(finalColor, 1.0);
        return;
    }

    // ── Fallback (should never be reached if uMode is 0, 1, or 2) ─────────
    FragColor = vec4(vColor, 1.0);
    // Output plain vertex colour if uMode is set to an unrecognised value.
}
