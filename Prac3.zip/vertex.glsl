#version 330 core
// Tells the GLSL compiler we are targeting OpenGL 3.3 Core Profile.
// Must be the very first line of every shader.

// ── Vertex attributes (inputs from the VBO) ───────────────────────────────
// These match the glVertexAttribPointer calls in main.cpp exactly.
// layout(location = N) must equal the first argument of glVertexAttribPointer.

layout(location = 0) in vec3 aPos;
// Attribute 0: the vertex position in MODEL space (local object coordinates).
// Comes from bytes 0–11 of each vertex in the VBO (3 floats × 4 bytes).

layout(location = 1) in vec3 aColor;
// Attribute 1: the per-vertex RGB colour baked into the geometry.
// Comes from bytes 12–23 of each vertex in the VBO.

// ── Uniforms (set once per draw call from the CPU) ────────────────────────
// A uniform is the same value for every vertex in one draw call.
// We set it with glUniformMatrix4fv(gMVPLoc, 1, GL_FALSE, mvp.ptr()).

uniform mat4 uMVP;
// The combined Model × View × Projection matrix.
// Transforms a vertex from model space all the way to clip space in one step:
//   Model       – places the object in the world
//   View        – transforms the world into camera space
//   Projection  – applies perspective (things farther away appear smaller)

// ── Outputs to the fragment shader ───────────────────────────────────────
// Values written to 'out' variables are interpolated across the triangle
// surface by the rasteriser.  A pixel at the midpoint of an edge receives
// the average of the two endpoint values.

out vec3 vColor;
// The colour that will reach the fragment shader.
// Because all corners of each face share the same colour in our geometry,
// interpolation has no visible effect — every pixel on a face gets the
// same flat colour.

out vec3 vWorldPos;
// The vertex position in WORLD space (after model transform, before view).
// Passed through so the fragment shader can use it for lighting or fog
// without needing to invert the full MVP.  Not used by the basic fragment
// shader below, but costs nothing to pass and avoids editing the shader
// pair if you add lighting later.

out vec3 vNormal;
// A placeholder normal vector passed to the fragment shader.
// Currently set to a constant (no normal data in the VBO).
// If you add normals as a third vertex attribute, wire it up here.

// ── Uniforms for the model matrix (needed to transform normals) ───────────
uniform mat4 uModel;
// The model-only matrix (no view or projection).
// Used to transform vWorldPos and vNormal into world space.
// Set with:  glUniformMatrix4fv(modelLoc, 1, GL_FALSE, model.ptr())
// If you do not need world-space positions or normals, this can be ignored —
// the shader still compiles and the vWorldPos/vNormal outputs will just be
// meaningless values (which the basic fragment shader does not read anyway).

void main() {

    // ── Clip-space position ───────────────────────────────────────────────
    gl_Position = uMVP * vec4(aPos, 1.0);
    // vec4(aPos, 1.0) promotes the vec3 position to homogeneous coordinates.
    // The w=1.0 means "this is a point" (w=0 would mean "this is a direction").
    // Without w=1, the translation part of the MVP would have no effect.
    //
    // After this line, gl_Position holds a clip-space coordinate.
    // OpenGL then automatically divides x, y, z by w (the "perspective divide"),
    // which makes far-away objects appear smaller.

    // ── Pass colour through unchanged ─────────────────────────────────────
    vColor = aColor;
    // Simply forward the per-vertex colour to the fragment shader.
    // No lighting calculation here — this gives flat unlit colours.

    // ── Compute world-space position ──────────────────────────────────────
    vWorldPos = vec3(uModel * vec4(aPos, 1.0));
    // Multiply by the model matrix (no view or projection) to get the vertex
    // position in world space.  The vec3(...) cast discards the w component.
    // Useful for: distance-based fog, point light calculations, debugging.

    // ── Placeholder normal ────────────────────────────────────────────────
    vNormal = vec3(0.0, 1.0, 0.0);
    // Hardcoded upward normal — a safe placeholder until you add real normals.
    // To use real normals:
    //   1. Add a third vertex attribute in the VBO (x,y,z,r,g,b,nx,ny,nz).
    //   2. Add  layout(location=2) in vec3 aNormal;  above.
    //   3. Replace this line with:
    //        vNormal = mat3(transpose(inverse(uModel))) * aNormal;
    //      (The mat3(transpose(inverse())) corrects normals for non-uniform scale.)
}
