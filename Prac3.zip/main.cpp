#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <thread>
#include <random>
#include <chrono> 

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

#include "shader.hpp"
#include "maths.hpp"
#include "shapes.hpp"

using namespace glm;
using namespace std;

const char *getError()
{
    const char *errorDescription;
    glfwGetError(&errorDescription);
    return errorDescription;
}

inline void startUpGLFW()
{
    glewExperimental = true; // Needed for core profile
    if (!glfwInit())
    {
        throw getError();
    }
}

inline void startUpGLEW()
{
    glewExperimental = true; // Needed in core profile
    if (glewInit() != GLEW_OK)
    {
        glfwTerminate();
        throw getError();
    }
}

inline GLFWwindow *setUp()
{
    startUpGLFW();
    glfwWindowHint(GLFW_SAMPLES, 4);               // 4x antialiasing
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3); // We want OpenGL 3.3
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);           // To make MacOS happy; should not be needed
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE); // We don't want the old OpenGL
    GLFWwindow *window;                                            // (In the accompanying source code, this variable is global for simplicity)
    window = glfwCreateWindow(1000, 1000, "u24597181", NULL, NULL);
    if (window == NULL)
    {
        cout << getError() << endl;
        glfwTerminate();
        throw "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n";
    }
    glfwMakeContextCurrent(window); // Initialize GLEW
    startUpGLEW();
    return window;
}

namespace V1 {
    // Course
    inline Colour grass()      { return {0.18f, 0.65f, 0.22f}; }  // bright green astroturf
    inline Colour grassDark()  { return {0.10f, 0.45f, 0.12f}; }
    inline Colour frame()      { return {0.39f,0.19f,0.08f}; }  // brown raised border frame
    inline Colour startMat()   { return {0.95f, 0.85f, 0.20f}; }  // yellow starting square

    // Windmill tower body
    inline Colour bodyBlue()   { return {0.20f, 0.40f, 0.80f}; }  // bright blue tower
    inline Colour bodyBlueDk() { return {0.15f, 0.30f, 0.65f}; }  // darker blue for shaded sides
    inline Colour trimWhite()  { return {0.95f, 0.95f, 0.95f}; }  // white trim/door surround
    inline Colour roofGrey()   { return {0.72f, 0.72f, 0.75f}; }  // grey roof

    // Blades – red and white striped lattice
    inline Colour bladeWhite() { return {0.95f, 0.95f, 0.95f}; }  // white spar (main beam)
    inline Colour bladeRed()   { return {0.85f, 0.10f, 0.10f}; }  // red cross-slats

    // Axle
    inline Colour axle()       { return {0.80f, 0.80f, 0.82f}; }  // light metallic
    inline Colour axleDark()   { return {0.55f, 0.55f, 0.58f}; }

    // Platform / base
    inline Colour platform()   { return {0.90f, 0.88f, 0.85f}; }  // light grey concrete
    inline Colour platDark()   { return {0.65f, 0.62f, 0.58f}; }

    // Decorations
    inline Colour tree()       { return {0.12f, 0.52f, 0.12f}; }
    inline Colour trunk()      { return {0.42f, 0.28f, 0.12f}; }
    inline Colour hole()       { return {0.05f, 0.05f, 0.05f}; }
    inline Colour flagPole()   { return {0.85f, 0.85f, 0.85f}; }
    inline Colour flagRed()    { return {0.90f, 0.10f, 0.10f}; }
}

struct Mesh {
    GLuint vao=0, vbo=0, solidEbo=0, wireEbo=0;
    unsigned int solidCount=0, wireCount=0;

    void build(const VBuffer& verts, const IBuffer& solid, const IBuffer& wire) {
        glGenVertexArrays(1,&vao);
        glGenBuffers(1,&vbo);
        glGenBuffers(1,&solidEbo);
        glGenBuffers(1,&wireEbo);
        glBindVertexArray(vao);

        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER,(GLsizeiptr)(verts.size()*sizeof(float)),
                     verts.data(), GL_STATIC_DRAW);

        glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)(3*sizeof(float)));
        glEnableVertexAttribArray(1);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, solidEbo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER,(GLsizeiptr)(solid.size()*sizeof(unsigned int)),
                     solid.data(), GL_STATIC_DRAW);
        solidCount=(unsigned int)solid.size();

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, wireEbo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER,(GLsizeiptr)(wire.size()*sizeof(unsigned int)),
                     wire.data(), GL_STATIC_DRAW);
        wireCount=(unsigned int)wire.size();

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, solidEbo);
        glBindVertexArray(0);
    }

    void drawSolid() const {
        if(!solidCount) return;
        glBindVertexArray(vao);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, solidEbo);
        glDrawElements(GL_TRIANGLES,(GLsizei)solidCount,GL_UNSIGNED_INT,nullptr);
        glBindVertexArray(0);
    }
    void drawWire() const {
        if(!wireCount) return;
        glBindVertexArray(vao);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, wireEbo);
        glDrawElements(GL_LINES,(GLsizei)wireCount,GL_UNSIGNED_INT,nullptr);
        glBindVertexArray(0);
    }
};

float gRotX=0,gRotY=0,gRotZ=0;
float gTX=0,gTY=0,gTZ=0;
float gRotorAngle=0, gRotorSpeed=0;
bool  gWireframe=false;
float gWireLastTime=0;
const float ROT_STEP=0.05f, TRANS_STEP=0.10f, SPEED_STEP=0.3f;

void processInput(GLFWwindow* win) {
    if(glfwGetKey(win,GLFW_KEY_ESCAPE)==GLFW_PRESS) glfwSetWindowShouldClose(win,true);
    if(glfwGetKey(win,GLFW_KEY_W)==GLFW_PRESS) gRotX-=ROT_STEP;
    if(glfwGetKey(win,GLFW_KEY_S)==GLFW_PRESS) gRotX+=ROT_STEP;
    if(glfwGetKey(win,GLFW_KEY_A)==GLFW_PRESS) gRotY-=ROT_STEP;
    if(glfwGetKey(win,GLFW_KEY_D)==GLFW_PRESS) gRotY+=ROT_STEP;
    if(glfwGetKey(win,GLFW_KEY_E)==GLFW_PRESS) gRotZ-=ROT_STEP;
    if(glfwGetKey(win,GLFW_KEY_Q)==GLFW_PRESS) gRotZ+=ROT_STEP;
    if(glfwGetKey(win,GLFW_KEY_I)==GLFW_PRESS) gTY+=TRANS_STEP;
    if(glfwGetKey(win,GLFW_KEY_K)==GLFW_PRESS) gTY-=TRANS_STEP;
    if(glfwGetKey(win,GLFW_KEY_L)==GLFW_PRESS) gTX+=TRANS_STEP;
    if(glfwGetKey(win,GLFW_KEY_J)==GLFW_PRESS) gTX-=TRANS_STEP;
    if(glfwGetKey(win,GLFW_KEY_O)==GLFW_PRESS) gTZ+=TRANS_STEP;
    if(glfwGetKey(win,GLFW_KEY_U)==GLFW_PRESS) gTZ-=TRANS_STEP;
    if(glfwGetKey(win,GLFW_KEY_EQUAL)==GLFW_PRESS) gRotorSpeed+=SPEED_STEP*0.016f;
    if(glfwGetKey(win,GLFW_KEY_MINUS)==GLFW_PRESS){
        gRotorSpeed-=SPEED_STEP*0.016f;
        if(gRotorSpeed<0) gRotorSpeed=0;
    }
    float now=(float)glfwGetTime();
    if(glfwGetKey(win,GLFW_KEY_ENTER)==GLFW_PRESS && (now-gWireLastTime)>0.30f){
        gWireframe=!gWireframe; gWireLastTime=now;
    }
}

static Mesh meshCourse, meshWindmill, meshRotor, meshDeco;

void buildScene() {
    VBuffer cv; IBuffer cs,cw;
    VBuffer wv; IBuffer ws,ww;
    VBuffer rv; IBuffer rs,rw;
    VBuffer dv; IBuffer ds,dw;

    // COURSE
    // Grass floor
    makeCuboid(cv,cs,cw, 10.0f,0.10f,5.0f,
                V1::grass(),V1::grass(),V1::grassDark(),
                0.0f,-0.10f,0.0f);

    // Front wall
    makeCuboid(cv,cs,cw, 10.5f,0.40f,0.30f,
                V1::frame(),V1::frame(),V1::frame(),
                0.0f,0.0f,2.65f);
    // Back wall
    makeCuboid(cv,cs,cw, 10.5f,0.40f,0.30f,
                V1::frame(),V1::frame(),V1::frame(),
                0.0f,0.0f,-2.65f);
    // Left wall
    makeCuboid(cv,cs,cw, 0.30f,0.40f,5.0f,
                V1::frame(),V1::frame(),V1::frame(),
                -5.25f,0.0f,0.0f);
    // Right wall
    makeCuboid(cv,cs,cw, 0.30f,0.40f,5.0f,
                V1::frame(),V1::frame(),V1::frame(),
                5.25f,0.0f,0.0f);

    // starting mat
    makeCuboid(cv,cs,cw, 1.0f,0.02f,1.0f,
                V1::startMat(),V1::startMat(),V1::startMat(),
                -3.5f,0.0f,0.0f);

    // Golf hole
    makeCylinder(cv,cs,cw, 0.18f,0.04f,12,
                  V1::hole(),V1::hole(),
                  3.2f, -0.02f,0.0f);

    makeCuboid(cv,cs,cw, 1.50f,0.12f,1.20f,
                V1::platform(),V1::platDark(),V1::platDark(),
                0.0f,0.18f,0.0f);
    meshCourse.build(cv,cs,cw);


    // WINDMILL
    float bx=0.0f;     // tower X centre (centred on course)
    float bz=0.0f;     // tower Z centre
    float by=0.30f;    // base Y = top of platform + step

    // Tower body, blue cuboid
    makeCuboid(wv,ws,ww, 1.10f,1.80f,0.90f,
                V1::bodyBlue(),V1::bodyBlue(),V1::bodyBlueDk(),
                bx,by,bz);

    // White trim strip at tower base
    makeCuboid(wv,ws,ww, 1.14f,0.10f,0.94f,
                V1::trimWhite(),V1::trimWhite(),V1::trimWhite(),
                bx,by,bz);

    // White trim strip at tower mid-height
    makeCuboid(wv,ws,ww, 1.14f,0.08f,0.94f,
                V1::trimWhite(),V1::trimWhite(),V1::trimWhite(),
                bx,by+0.90f,bz);

    // White trim strip at tower top
    makeCuboid(wv,ws,ww, 1.14f,0.08f,0.94f,
                V1::trimWhite(),V1::trimWhite(),V1::trimWhite(),
                bx,by+1.78f,bz);

    // Door opening
    makeCuboid(wv,ws,ww, 0.32f,0.55f,0.06f,
                V1::bodyBlueDk(),V1::bodyBlueDk(),V1::bodyBlueDk(),
                bx,by+0.02f,bz-0.48f);

    // White door frame
    makeCuboid(wv,ws,ww, 0.40f,0.63f,0.04f,
                V1::trimWhite(),V1::trimWhite(),V1::trimWhite(),
                bx,by+0.01f,bz-0.46f);

    // Tunnel gap markers
    // left
    makeCuboid(wv,ws,ww, 1.90f, 0.18f, 1.22f,
                V1::platform(),V1::platDark(),V1::platDark(),
                bx - 1.25f, 0.0f, 0.0f); 
    // right    
    makeCuboid(wv,ws,ww, 1.90f, 0.18f, 1.12f,
                V1::platform(),V1::platDark(),V1::platDark(),
                bx + 1.25f, 0.0f, 0.0f);

    // Roof
    {
        float roofBase = 0.55f;   // half-depth of roof base
        float roofH    = 0.90f;   // roof height
        float roofHW   = 0.60f;   // half-width of the roof

        makeTriPrism(wv,ws,ww,
                       0.0f,  roofH,   // apex
                      -roofBase, 0.0f, // left base corner
                       roofBase, 0.0f, // right base corner
                      -roofHW, roofHW, // z extents
                      V1::roofGrey(), V1::roofGrey(),
                      bx, by+1.80f, bz);
    }

    // Small white window
    makeCuboid(wv,ws,ww, 0.22f,0.22f,0.04f,
                V1::trimWhite(),V1::trimWhite(),V1::trimWhite(),
                bx,by+1.10f,bz-0.47f);

    meshWindmill.build(wv,ws,ww);

    // ROTOR
    float rotY = 1.20f;

    // Centre
    makeCylinderZ(rv, rs, rw, 0.16f, 0.06f, 12,
                 V1::bladeRed(), V1::bladeRed(), V1::bladeRed(),
                 -0.01f, rotY-0.03f, -0.50f);

    makeCylinderZ(rv, rs, rw, 0.08f, 0.08f, 12,
                 V1::axle(), V1::axle(), V1::axle(),
                 -0.01f, rotY-0.03f, -0.50f);

    // Blade dimensions
    float sparLen   = 0.70f;
    float sparW     = 0.06f;
    float sparThick = 0.04f;
    float slatW     = 0.16f;
    float slatH     = 0.04f;
    float slatThk   = 0.03f;
    float innerGap  = 0.10f;

    // All blade parts
    auto addBlade = [&](float dx, float dy) {
        if (fabs(dy) > fabs(dx)) {
            // Vertical spar
            float scy = rotY + dy * (innerGap + sparLen * 0.5f);
            makeCuboid(rv, rs, rw, sparW, sparLen, sparThick,
                        V1::bladeWhite(), V1::bladeWhite(), V1::trimWhite(),
                        0.0f, scy - 0.35, -0.50f);
            for (int i = 0; i < 4; i++) {
                float t = -sparLen * 0.5f + (i + 0.5f) * (sparLen / 4.0f);
                makeCuboid(rv, rs, rw, slatW, slatH, slatThk,
                            V1::bladeRed(), V1::bladeRed(), V1::bladeRed(),
                            0.0f, scy + t, -0.50f);
            }
        } else {
            // Horizontal spar
            float scx = dx * (innerGap + sparLen * 0.5f);
            makeCuboid(rv, rs, rw, sparLen, sparW, sparThick,
                        V1::bladeWhite(), V1::bladeWhite(), V1::trimWhite(),
                        scx, rotY - 0.01, -0.50f);
            for (int i = 0; i < 4; i++) {
                float t = -sparLen * 0.5f + (i + 0.5f) * (sparLen / 4.0f);
                makeCuboid(rv, rs, rw, slatH, slatW, slatThk,
                            V1::bladeRed(), V1::bladeRed(), V1::bladeRed(),
                            scx + t, rotY - 0.05, -0.50f);
            }
        }
    };

    addBlade(0.0f,  1.0f); // up
    addBlade(1.0f,  0.0f); // right
    addBlade(0.0f, -1.0f); // down
    addBlade(-1.0f, 0.0f); // left

    meshRotor.build(rv, rs, rw);

    // DECORATIONS
    // Tree 1, right
    makeCylinder(dv,ds,dw, 0.12f,0.55f,8,
                  V1::trunk(),V1::trunk(),
                  6.2f,0.0f,1.2f);
    makeCone(dv,ds,dw, 0.42f,0.80f,10,
              V1::tree(),V1::tree(),
              6.2f,0.55f,1.2f);

    // Tree 2, left
    makeCylinder(dv,ds,dw, 0.12f,0.55f,8,
                  V1::trunk(),V1::trunk(),
                  -6.2f,0.0f,-0.8f);
    makeCone(dv,ds,dw, 0.42f,0.80f,10,
              V1::tree(),V1::tree(),
              -6.2f,0.55f,-0.8f);

    // Flag pole and flag
    makeCylinder(dv,ds,dw, 0.03f,0.75f,8,
                  V1::flagPole(),V1::flagPole(),
                  3.2f,0.05f,0.0f);
    makeCuboid(dv,ds,dw, 0.29f,0.14f,0.01f,
                V1::flagRed(),V1::flagRed(),V1::flagRed(),
                3.2f+0.11f,0.80f,0.0f);

    meshDeco.build(dv,ds,dw);
}

// Draw helper
static GLint gMVPLoc=-1;
void drawMesh(const Mesh& m, const Mat4& mvp, bool wire){
    glUniformMatrix4fv(gMVPLoc,1,GL_TRUE,mvp.pointer());
    if(wire) m.drawWire(); else m.drawSolid();
}



int main(){
    GLFWwindow* window;
    try{ window=setUp(); }
    catch(const char* e){ cout<<e<<endl; throw; }

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.55f, 0.78f, 0.92f, 1.0f);

    GLuint prog = LoadShaders("vertex.glsl", "fragment.glsl");
    if (prog == 0) {
        std::cerr << "Failed to load shaders!" << std::endl;
        glfwTerminate();
        return -1;
    }

    gMVPLoc = glGetUniformLocation(prog, "uMVP");
    if (gMVPLoc == -1) {
        std::cerr << "Warning: Could not find uMVP uniform" << std::endl;
    }
    buildScene();

    // CAMERA
    Mat4 proj=Mat4::perspective(
        (float)(45.0*M_PI/180.0), 1.0f, 0.1f, 100.0f);
    Mat4 view=Mat4::look(
        {0.0f, 4.0f, 10.0f},
        {0.0f, 1.0f,  0.0f},
        {0.0f, 1.0f,  0.0f});

    // Rotor pivot
    const float rPX=0.0f, rPY=1.20f, rPZ=-0.50f;

    float lastTime=(float)glfwGetTime();
    gRotorAngle = (float)(M_PI/4.0);

    while(!glfwWindowShouldClose(window)){
        float now=(float)glfwGetTime();
        float dt=now-lastTime; lastTime=now;
        glfwPollEvents();
        processInput(window);
        gRotorAngle+=gRotorSpeed*dt;

        Mat4 world=
            Mat4::translation(gTX,gTY,gTZ)*
            Mat4::rotateX(gRotX)*
            Mat4::rotateY(gRotY)*
            Mat4::rotateZ(gRotZ);

        Mat4 pv = proj * view;
        Mat4 mvpStatic = pv * world;

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glUseProgram(prog);

        GLint modelLoc = glGetUniformLocation(prog, "uModel");
        Mat4 identity = Mat4::identity();
        glUniformMatrix4fv(modelLoc, 1, GL_TRUE, identity.pointer());

        bool w = gWireframe;

        Mat4 windmillRot = Mat4::rotateY(M_PI / 2.0f); // Rotate windmill for correct orientation

        // Course stays fixed
        drawMesh(meshCourse, mvpStatic, w);

        // Windmill tower and rotor get the rotation
        Mat4 mvpWindmill = pv * world * windmillRot;
        drawMesh(meshWindmill, mvpWindmill, w);

        // Rotor spin on top of windmill rotation
        Mat4 rotorLocal = Mat4::translation(rPX, rPY, rPZ) *
                          Mat4::rotateZ(gRotorAngle) *
                          Mat4::translation(-rPX, -rPY, -rPZ);
        Mat4 mvpRotor = pv * world * windmillRot * rotorLocal;
        drawMesh(meshRotor, mvpRotor, w);

        // Decorations stay fixed with the course
        drawMesh(meshDeco, mvpStatic, w);

        glfwSwapBuffers(window);
    }
    glfwTerminate();
    return 0;
}